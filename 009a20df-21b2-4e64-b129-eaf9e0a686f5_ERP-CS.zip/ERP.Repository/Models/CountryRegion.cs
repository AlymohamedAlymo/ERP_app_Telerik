﻿namespace ERP.Repository.Service
{
    public partial class CountryRegion
    {
        public override string ToString()
        {
            return this.Name;
        }
    }
}
