﻿namespace ERP.Repository.Service
{
    public partial class ShipMethod
    {
        public override string ToString()
        {
            return this.Name;
        }
    }
}
