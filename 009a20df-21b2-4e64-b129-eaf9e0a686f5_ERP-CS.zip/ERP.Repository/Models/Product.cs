﻿namespace ERP.Repository.Service
{
    public partial class Product
    {
        public override string ToString()
        {
            return this.Name;
        }
    }
}
