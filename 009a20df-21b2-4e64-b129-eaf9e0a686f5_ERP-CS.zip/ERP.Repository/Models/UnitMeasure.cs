﻿namespace ERP.Repository.Service
{
    public partial class UnitMeasure
    {
        public override string ToString()
        {
            return this.Name;
        }
    }
}
