﻿namespace ERP.Repository.Service
{
    public partial class Location
    {
        public override string ToString()
        {
            return this.Name;
        }
    }
}
